# SILIA - Software Implementation of a Lock-In Amplifier

A software implementation of a multi channel and multi frequency lock-in amplifier to extract periodic features from data
